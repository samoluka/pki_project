import { Router } from "../Router/Router";

const UserApp = () => {
  return <Router />;
};

export default UserApp;
