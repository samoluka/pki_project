export class OrderNotification {
  username: string;
  order_id: number;
}
